from .highlighter import *

__doc__ = highlighter.__doc__
if hasattr(highlighter, "__all__"):
    __all__ = highlighter.__all__